<?php 
    session_start();   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
    <div id="all">
        <div id="pierwszy">
            <ol>
                <li>nwm</li>
                <li>nwm</li>
                <li>nwm</li>
                <li>nwm</li>
                <li>nwm</li>
            </ol>
        </div>
        <div id="drugi"> 
                <img src="Unknown.jpeg" style="width: 40%;" id="zdj" onmouseover="nowa()" onmouseout="dwa()"><br>

                <form action="dodaj.php" method="post">
                    <h3>Rezerwacja</h3>
                        <span>Data: </span> <input type="date" name="data" id="data" required><br>
                        <input type="text" name="mail" id="mail" placeholder="mail" required><br>
                        <input type="checkbox" name="" id="" required><span>Akceptuje Regulamin</span><br>
                        <input type="button" value="Wyczysc" onclick="wyczysc()">
                        <input type="submit" value="Wyslij">
                </form>
                <?php
                    if (isset($_SESSION["nwm"]) == true) {
                        echo "błędny mail";
                    }
                ?>

        </div>
        <div style="clear: both;"></div>
    <footer>kamil</footer>
        <script>
            let x = document.getElementById("zdj");

            function nowa(){
                x.src = "images.jpeg";
            }

            function dwa(){
                x.src = "Unknown.jpeg";
            }

            function wyczysc(){
                document.getElementById("data").value = "";
                document.getElementById("mail").value = "";
            }
        </script>
    </div>
</body>
</html>
