<?php
    session_start();
    $mail = $_POST['mail'];
    $data = $_POST['data'];
    $test = false;

    $regex = '/^([a-zA-Z0-9]+@[a-zA-Z]+(\.)+[a-zA-Z]{2,3})$/';

    if(!preg_match($regex, $mail)){
        $test = true;
        header('Location: index.php');
        exit();
        
    } else {
        unset($_SESSION["nwm"]);
        $host = "localhost";
        $db_user = "root";
        $db_password = "";
        $db_name = "html4";
    
        $conn = new mysqli($host, $db_user, $db_password, $db_name);
    
        if(isset($mail)){
            if(isset($data)){
                $sql = "INSERT INTO html4 (mail, data) VALUES ('$mail', '$data')";
    
                if($conn->query($sql) === true){
                    echo "wartosci zostaly dodane do bz";
                } else {
                    echo "cos sie zepsulo";
                }
    
            }
        }
    }


?>
